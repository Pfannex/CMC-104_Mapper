Contributing to Curio
=====================

Although Curio is made available as open-source software, it is not
developed as a community project.  Thus, pull requests are not
accepted except by invitation. However, if you have found a bug, a
typo, or have an idea for improvement, please submit an issue instead.
