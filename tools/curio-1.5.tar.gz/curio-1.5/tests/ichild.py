# ichild.py

import sys
for lineno, line in enumerate(sys.stdin, start=1):
    pass

print(lineno)


